egrep "average|MUTE" ./mutecall-14_09_2016 > ./mutecall-14_09_2016.log
mailx -v  -S smtp="10.162.168.195:25" -s "mutecall report: 14/09/2016 OMCR SE1 LYON"  lromeiro.ext@orange.com < ./mutecall-14_09_2016.log
# /alcatel/base/doc/gsm/jre_linux/Welcome.html
